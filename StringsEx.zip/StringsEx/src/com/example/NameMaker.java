/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;
import java.util.Scanner;

public class NameMaker {
    public static Scanner en = new Scanner(System.in);
    public static void main(String args[])
    {
        String firstName;
        String middleName;
        String lastName;
        String fullName;
        
        System.out.println("Ingrese su nombre: ");
        firstName = en.nextLine();
        
        System.out.println("Ingrese su apellido Paterno: ");
        middleName = en.nextLine();
        
        System.out.println("Ingrese su apellido Materno: ");
        lastName = en.nextLine();
        fullName = firstName +" "+ middleName + " " + lastName;
        System.out.println("Su nombre completo es: " + fullName);
        
        
        
        
    }
    
}
